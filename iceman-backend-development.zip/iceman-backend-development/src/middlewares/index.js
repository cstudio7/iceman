import auth from './auth';
import permitUser from './permission';

export default { auth, permitUser };
